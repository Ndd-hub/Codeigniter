<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Validation</title>
   </head>
   <body>
     <?= Validation_errors()?>
     <form  action="" method="post" >
       Name:<input type="text" name="Name" ><br><br>
       Email Id: <input type="text" name="Email Id" ><br><br>
       Mobile No.:<input type="number" name="Mobile No" ><br><br>
       Date of Birth:<input type="date" name="Date of Birth" ><br><br>
       Pin Code:<input type="number" name="Pin Code" ><br><br>
       <input type="submit" name="submit" value="sumit">
     </form>
   </body>
 </html>
