<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Crud Application- Create User</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">
  </head>
  <body>
  <div class="navbar navbar-dark bg-dark">
<div class="container">
  <a href="#" class="navbar-brand">  <h1>CRUD APPLICATION</h1></a>
</div>
</div>
    <div class="container" style="padding-top:10px;">
      <h3>Create User</h3>
      <hr>
      <form method="post" name="createUser" action="<?php echo base_url().'index.php/user/create';?>">
     <div class="row">
      <div class="col-md-6">
         <div class="form-group">
           <label> Name</label>
         <input type="text"  name="name" value="<?php echo set_value('name');?>" class="form-control">
         <?php echo form_error('name');?>
      </div>
        <div class="form-group">
          <label>Email Id</label>
        <input type="text"  name="email Id" value="<?php echo set_value('email Id');?>" class="form-control">
                <?php echo form_error('email Id');?>
          </div>
        <div class="form-group">
          <label>Mobile No.</label>
        <input type="number" name="mobile No."   value="<?php echo set_value('mobile No.');?>" class="form-control">
                <?php echo form_error('mobile No.');?>
          </div>
        <div class="form-group">
          <label>Date of Birth</label>
        <input type="date" name="date of birth" value="<?php echo set_value('date of birth');?>" class="form-control">
                <?php echo form_error('date of birth');?>
          </div>
        <div class="form-group">
           <label>Pin Code</label>
        <input type="number" name="pin code" value="<?php echo set_value('pin code');?>" class="form-control">
                <?php echo form_error('pin code');?>
          </div>
        <div class="form-group">
          <button  class="btn btn-primary" type="button" name="button">Create</button>
          <a href="" class="btn-secondary btn">Cancel</a>
        </div>
      </div>
    </div>
  </form>
  </div>
  </body>
</html>
