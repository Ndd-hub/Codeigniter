<?php
  error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CRUD Operations</title>

  </head>
  <body>

     <h1><marquee>CRUD APPLICATION</marquee></h1>
      <hr>
      <br><br>
     <form method="post" action="<?php echo base_url();?>record/<?php echo isset($modify) ?"update_record":"add_record";?>">
       <input type="hidden" name="hid" value="<?php echo $modify['id'];?>">
      <center>
        <table cellspacing="10px" >
          <tr>
            <td>Name</td>
            <td><input value="<?php echo $modify['name']; ?>" type="text" name="userName" placeholder="Enter Name"</td>
          </tr>
          <tr>
            <td>Email Id</td>
            <td><input value="<?php echo $modify['email Id']; ?>" type="text" name="useremailId" placeholder="xyz@gmail.com"</td>
          </tr>

          <tr>
            <td>Mobile No.</td>
            <td><input value="<?php echo $modify['mobile No.']; ?>" type="number" name="userMobileNo." placeholder="Enter valid Mobile No."</td>
          </tr>

          <tr>
            <td>Date Of Birth</td>
            <td><input type="date" value="<?php echo $modify['date of birth']; ?>"name="dateofbirth" </td>
          </tr>
          <tr>
            <td>Pin Code</td>
            <td><input value="<?php echo $modify['pin code']; ?>" type="number" name="pincode" placeholder="Enter 6-digit pincode"</td>
          </tr>
          <tr>
             <td></td>
             <td><input type="submit" value="Save Details" ></td>
          </tr>

        </table>
      </center>

    </form>
    <br><br>
    <hr>
<center>
  <br><br>
  <table border="1px" cellspacing="5px" cellpadding="5px">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Name</th>
        <th>Email Id</th>
        <th>Mobile No.</th>
        <th>Date Of Birth</th>
        <th>Pin Code</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $cnt=1;
      foreach($record as $r)
      { ?>
      <tr>
        <td><?php echo $cnt++; ?></td>
        <td><?php echo $r['name']; ?></td>
        <td><?php echo $r['email Id']; ?></td>
        <td><?php echo $r['mobile No.']; ?></td>
        <td><?php echo $r['date of birth']; ?></td>
        <td><?php echo $r['pin code']; ?></td>
        <td>
          <a  href="<?php echo base_url(); ?>record/modify/<?php echo $b['id']; ?>">Modify</a>
        <hr>
          <a onclick="return confirm('Are You Sure To Remove A Record???');" href="<?php echo base_url(); ?>record/remove/<?php echo $b['id']; ?>">Remove</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</center>
  </body>
</html>
