
<?php
  error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Crud Application</title>

  </head>
  <body>

     <h1><marquee>CRUD APPLICATION</marquee></h1>
      <hr>
      <br><br>
     <form method="post" action="<?php echo base_url();?>bill/<?php echo isset($modify) ?"update_bill":"add_bill";?>">
       <input type="hidden" name="hid" value="<?php echo $modify['id'];?>">
      <center>
        <table cellspacing="10px" >
          <tr>
            <td>Customer Name</td>
            <td><input value="<?php echo $modify['customer_name']; ?>" type="text" name="custName" placeholder="Customer Name"</td>
          </tr>
          <tr>
            <td>Customer Number</td>
            <td><input value="<?php echo $modify['customer_no']; ?>" type="text" name="custNumber" placeholder="Customer Number"</td>
          </tr>

          <tr>
            <td>Contact Number</td>
            <td><input value="<?php echo $modify['mobile']; ?>" type="number" name="custMobile" placeholder="Contact Number"</td>
          </tr>

          <tr>
            <td>Bill Amount</td>
            <td><input value="<?php echo $modify['amount']; ?>" type="number" name="billAmount" placeholder="Amount of the bill"</td>
          </tr>

          <tr>
            <td>Bill Date</td>
            <td><input type="date" value="<?php echo $modify['date']; ?>"name="billDate" </td>
          </tr>

          <tr>
             <td></td>
             <td><input type="submit" value="Save Bill Detail" ></td>
          </tr>

        </table>
      </center>

    </form>
    <br><br>
    <hr>
<center>
  <br><br>
  <table border="1px" cellspacing="5px" cellpadding="5px">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Customer Name</th>
        <th>Customer Number</th>
        <th>Bill Amount</th>
        <th>Bill Date</th>
        <th>Contact No.</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $cnt=1;
      foreach($bill as $b)
      { ?>
      <tr>
        <td><?php echo $cnt++; ?></td>
        <td><?php echo $b['customer_name']; ?></td>
        <td><?php echo $b['customer_no']; ?></td>
        <td><?php echo $b['amount']; ?></td>
        <td><?php echo $b['date']; ?></td>
        <td><?php echo $b['mobile']; ?></td>
        <td>
          <a  href="<?php echo base_url(); ?>bill/modify/<?php echo $b['id']; ?>">Modify</a>
        <hr>
          <a onclick="return confirm('Are You Sure To Remove A Bill Record???');" href="<?php echo base_url(); ?>bill/remove/<?php echo $b['id']; ?>">Remove</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</center>
  </body>
</html>
