<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Validation</title>
   </head>
   <body>
     <form  action="" >
       Name:<input type="text" name="Name" value="">
       Email Id: <input type="text" name="Email Id" value="">
       Mobile No.:<input type="number" name="Mobile No" value="">
       Date of Birth:<input type="date" name="Date of Birth" value="">
       Pin Code:<input type="number" name="Pin Code" value="">
       <input type="submit" name="submit" value="sumit">
     </form>
   </body>
 </html>
