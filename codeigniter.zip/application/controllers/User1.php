<?php
defined('BASEPATH') OR exit('No direct script access allowed');


  class User1 extends CI_Controller{
    public function __construct(){
      parent::__construct();
      $this-> load ->model('User_model','data');
    }
    public function index(){
      $info['record']=$this->data->get_table_data('user_detail');
      $this-> load ->view('record',$info);

    }
    public function add_record(){
      $data= array(
        'name'=> $this->input->post('userName'),
        'email Id'=> $this->input->post('useremailId'),
        'mobile No.'=> $this->input->post('userMobileNo.'),
        'date of birth'=> $this->input->post('dateofbirth'),
        'pin code'=> $this->input->post('pincode')

      );
      $this->data->insert_data('user_detail',$data);
      header('location:'.base_url().'record');
    }
      public function update_record(){
        $id=$this->input->post('hid');
        $data= array(
          'name'=> $this->input->post('userName'),
          'email Id'=> $this->input->post('useremailId'),
          'mobile No.'=> $this->input->post('userMobileNo.'),
          'date of birth'=> $this->input->post('dateofbirth'),
          'pin code'=> $this->input->post('pincode')

        );
        $this->data->update_data('user_detail',$data,$id);
        header('location:'.base_url().'record');
      }
      public function modify(){
      $id=$this->uri->segment(2);
      $info['modify']=$this->data->get_modify_data('user_detail',$id);
      $info['record']=$this->data->get_table_data('user_detail');
      $this->load->view('record',$info);
    }
    public function remove(){
      $id=$this->uri->segment(2);
      $this->data->remove_record('user_detail',$id);
      header('location:'.base_url().'record');
    }
    }
