<?php
class Home extends CI_Controller{
  function index()
  {

  }
}
