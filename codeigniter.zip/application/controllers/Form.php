<?php
defined('BASEPATH') OR exit('No direct script access allowed');


  class Form extends CI_Controller{
    public function __construct(){
      parent::__construct();
      $this-> load ->library('form_validation');
    }
    public function index(){
      $this-> form_validation->set_rules('Name',' Name','required');
      $this-> form_validation->set_rules('Email Id',' Email Id','required');
      $this-> form_validation->set_error_delimiters('div class="error">','</div>');
      if($this-> form_validation->run() ==false){
      $this-> load ->view('form');
    }
       else {
         $this->load->view('success');
       }
   }
  }
?>
