<?php
class User extends CI_controller{

  function create(){
    $this->load->model('User_model');
    $this->form_validation->set_rules('name','Name','required');
    $this->form_validation->set_rules('email Id','Email Id','required');
    $this->form_validation->set_rules('mobile No.','Mobile No.','required');
    $this->form_validation->set_rules('date of birth','Date of Birth','required');
    $this->form_validation->set_rules('pin code','Pin Code','required');
    if($this-> form_validation->run() == false){
    $this-> load ->view('create');
  }
     else {
      $formArray = array();
      $formArray['name']= $this->input->post('name');
      $formArray['email Id']= $this->input->post('email Id');
      $formArray['mobile No.']= $this->input->post('mobile No.');
      $formArray['date of birth']= $this->input->post('date of birth');
      $formArray['pin code']= $this->input->post('pin code');
      $this->User_model->create($formArray);
      $this->session->set_flashdata('success','Record added successfully');
      redirect(base_url().'index.php/user/index');



     }
  }
}
?>
